# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import hr
from . import hr_advance_salary
from . import account_payment
from . import hr_payslip
from . import skip_installment
from . import full_payment
