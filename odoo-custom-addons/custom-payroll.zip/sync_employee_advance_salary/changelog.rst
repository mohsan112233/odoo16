============
[12.0.1.0.1]
[FIX] Fix the issue of external ID.
