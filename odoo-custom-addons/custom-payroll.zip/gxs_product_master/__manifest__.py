

{
    "name": "Product Master Data odoo16",
    "description": """Developed in GXS""",
    "summary": "Not Mentioned",
    "category": "apps",
    "version": "16.0.1.0.0",
    'author': 'Mohsan Raza',
    'company': 'Global XS',
    'maintainer': 'Global XS',
    'website': "",
    "depends": ['product'],
    "data": [
        'security/ir.model.access.csv',
        'views/master_record_views.xml'
    ],
    'images': [],
    'license': 'LGPL-3',
    'installable': True,
    'application': False,
    'auto_install': False,
}
