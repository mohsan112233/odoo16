Employee Late Check-in Penalty v13
==================================
Employee Late Check-in

Installation
============
	- www.odoo.com/documentation/13.0/setup/install.html
	- Install our custom addon

Configuration
=============

    No additional configurations needed

Credits
=======
    Developer: Ijaz Ahammed v13 @ cybrosys, Contact: odoo@cybrosys.com

