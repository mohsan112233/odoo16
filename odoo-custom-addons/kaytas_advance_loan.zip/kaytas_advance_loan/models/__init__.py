from . import kaytas_payments
from . import deduct_fully_loan
from . import loan_emp
