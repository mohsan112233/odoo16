from . import attendance_adjustment
from . import hr_payslip
from . import attendance_request
# from . import outdoor_work
# from . import remote_work
# from . import assumption_request
# from . import shift_change_request
from . import annual_leaves
from . import settings
# from . import late_chack_in
from . import time_settings

# from . import attendance_adjustment
# from . import hr_payslip
# from . import attendance_request
# from . import outdoor_work
# from . import remote_work
# from . import assumption_request
# from . import shift_change_request
# from . import annual_leaves
# from . import settings
# from . import late_chack_in
# from . import time_settings
