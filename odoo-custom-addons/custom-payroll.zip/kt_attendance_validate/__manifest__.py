{
    'name': "Kaytex Attendance Validity",
    'author': 'GlobalXS technology Solutions',
    'category': 'CRM',
    'license': 'AGPL-3',
    'website': 'http://www.globalxs.co',
    'description': """
""",
    'version': '1.0',
    'depends': ['hr_attendance'
        ],
    'data': [

        ],
    'installable': True,
    'application': True,
    'auto_install': False,
}
