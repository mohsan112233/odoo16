# -*- coding: utf-8 -*-

from . import by_shift_report
